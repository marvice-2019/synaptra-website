(function(){
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const reduce=matchMedia("(prefers-reduced-motion: reduce)").matches;
const PHONE="917818005561";

/* mobile menu */
const nav=$("#nav"), mb=$("#menuBtn");
if(mb){mb.addEventListener("click",()=>{const o=nav.classList.toggle("open");mb.setAttribute("aria-expanded",o);});}

/* year */
document.querySelectorAll("[data-year]").forEach(e=>e.textContent=new Date().getFullYear());

/* copy phone */
document.querySelectorAll("[data-copy]").forEach(b=>b.addEventListener("click",()=>{
  const t=b.dataset.copy, label=b.textContent, target=document.getElementById(b.dataset.target||"");
  const fallback=()=>{if(target)getSelection().selectAllChildren(target);};
  try{navigator.clipboard.writeText(t).then(()=>{b.textContent="Copied";setTimeout(()=>b.textContent=label,1600);},fallback);}catch(_){fallback();}
}));

/* forms -> WhatsApp */
document.querySelectorAll("form[data-wa]").forEach(f=>f.addEventListener("submit",e=>{
  e.preventDefault();
  const out=f.querySelector(".msg"); const lines=[f.dataset.wa]; let missing=false;
  f.querySelectorAll("[data-label]").forEach(el=>{
    const v=el.value.trim(); if(el.required&&!v)missing=true;
    lines.push(el.dataset.label+": "+(v||"-"));
  });
  if(missing){out.textContent="Please fill in your name and mobile number so our team can reply.";return;}
  const url="https://wa.me/"+PHONE+"?text="+encodeURIComponent(lines.join("\n"));
  const a=document.createElement("a");a.href=url;a.target="_blank";a.rel="noopener";document.body.appendChild(a);a.click();a.remove();
  out.innerHTML='WhatsApp should open with your message. If it doesn\'t, <a href="'+url+'" target="_blank" rel="noopener">tap here</a> or call +91 78180 05561.';
}));

/* product catalogue */
const rows=$("#rows");
if(rows&&window.SYN){
  const P=window.SYN, G=window.SYN_GROUPS;
  const ids=G.map(g=>g.id);
  let st={g:ids.includes(location.hash.slice(1))?location.hash.slice(1):"all",q:"",f:"all",limit:25};
  const chips=$("#chips"), fs=$("#formSel");
  [{id:"all",name:"All products"},...G].forEach(g=>{
    const n=g.id==="all"?P.length:P.filter(p=>p.g===g.id).length;
    chips.insertAdjacentHTML("beforeend",`<button class="chip" type="button" data-g="${g.id}" aria-pressed="false">${g.name} (${n})</button>`);
  });
  const forms=[...new Set(P.map(p=>p.form))];
  fs.innerHTML='<option value="all">All dosage forms</option>'+forms.map(f=>`<option value="${f}">${f}</option>`).join("");
  function render(){
    const q=st.q.trim().toLowerCase();
    const list=P.filter(p=>(st.g==="all"||p.g===st.g)&&(st.f==="all"||p.form===st.f)&&(!q||(p.brand+" "+p.comp+" "+p.therapy).toLowerCase().includes(q)));
    const shown=list.slice(0,st.limit);
    rows.innerHTML=shown.length?shown.map(p=>`<tr>
      <td class="brand"><a href="${p.slug}.html">${esc(p.brand)}</a></td>
      <td class="comp">${esc(p.comp)}</td>
      <td class="small">${esc(p.therapy)}</td>
      <td class="small">${esc(p.form)}${p.pack?" · "+esc(p.pack):""}</td>
      <td class="type"><span class="tag ${p.reg==="NRx"?"nrx":"rx"}">${esc(p.reg)}</span></td></tr>`).join("")
      :`<tr><td colspan="5" class="empty">No products match “${esc(st.q)}”. Try a molecule name such as Sertraline or Pregabalin.</td></tr>`;
    $("#count").textContent=`Showing ${shown.length} of ${list.length} products`;
    $("#moreBtn").hidden=shown.length>=list.length;
    chips.querySelectorAll(".chip").forEach(c=>c.setAttribute("aria-pressed",c.dataset.g===st.g));
  }
  chips.addEventListener("click",e=>{const b=e.target.closest(".chip");if(!b)return;st.g=b.dataset.g;st.limit=25;render();});
  $("#q").addEventListener("input",e=>{st.q=e.target.value;st.limit=25;render();});
  fs.addEventListener("change",e=>{st.f=e.target.value;st.limit=25;render();});
  $("#moreBtn").addEventListener("click",()=>{st.limit+=25;render();});
  addEventListener("hashchange",()=>{const h=location.hash.slice(1);if(ids.includes(h)){st.g=h;render();}});
  render();
}

/* synapse canvas */
const c=$("#syn");
if(c){
  const x=c.getContext("2d"); let W,H,N=[],pulses=[];const dpr=Math.min(devicePixelRatio||1,2);
  function size(){W=c.clientWidth;H=c.clientHeight;c.width=W*dpr;c.height=H*dpr;x.setTransform(dpr,0,0,dpr,0,0);
    const n=Math.round(Math.min(70,W*H/14000));N=[];
    for(let i=0;i<n;i++)N.push({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.18,vy:(Math.random()-.5)*.18,r:1.2+Math.random()*2});}
  function frame(){
    x.clearRect(0,0,W,H);const L=140;
    for(let i=0;i<N.length;i++)for(let j=i+1;j<N.length;j++){
      const a=N[i],b=N[j],d=Math.hypot(a.x-b.x,a.y-b.y);
      if(d<L){x.strokeStyle=`rgba(92,194,255,${(1-d/L)*.22})`;x.lineWidth=1;x.beginPath();x.moveTo(a.x,a.y);x.lineTo(b.x,b.y);x.stroke();
        if(!reduce&&Math.random()<.0009)pulses.push({a,b,t:0});}}
    N.forEach(n=>{x.fillStyle="rgba(120,215,240,.75)";x.beginPath();x.arc(n.x,n.y,n.r,0,7);x.fill();
      if(!reduce){n.x+=n.vx;n.y+=n.vy;if(n.x<0||n.x>W)n.vx*=-1;if(n.y<0||n.y>H)n.vy*=-1;}});
    pulses=pulses.filter(p=>p.t<=1);
    pulses.forEach(p=>{p.t+=.02;const px=p.a.x+(p.b.x-p.a.x)*p.t,py=p.a.y+(p.b.y-p.a.y)*p.t;
      const g=x.createRadialGradient(px,py,0,px,py,8);g.addColorStop(0,"rgba(79,227,233,.95)");g.addColorStop(1,"rgba(79,227,233,0)");
      x.fillStyle=g;x.beginPath();x.arc(px,py,8,0,7);x.fill();});
    if(!reduce)requestAnimationFrame(frame);
  }
  size();frame();addEventListener("resize",()=>{size();if(reduce)frame();});
}
})();
